var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session');
var path = require('path');
var moment = require('moment');
const flash = require('express-flash');

app.use(flash());
app.use(bodyParser.urlencoded({
  extended: true
}));


app.use(session({
  secret: 'BENITEZGINO',
  resave: false,
  saveUninitialized: true,
  cookie: {
    maxAge: 60000
  }
}))


app.use(express.static(path.join(__dirname, './static')));

app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/message_board');
mongoose.Promise = global.Promise;



const CommentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Comment must have an author."]
  },
  comment: {
    type: String,
    required: [true, "Comment must have content"]
  },
}, {
    timestamps: true
  })


const PostSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Posts must have an author."]
  },
  post: {
    type: String,
    required: [true, "Posts must have content."]
  },
  Comment: [CommentSchema]
}, {
    timestamps: true
  })


mongoose.model('Post', PostSchema); // We are setting this Schema in our Models as 'Post'
mongoose.model('Comment', PostSchema); // We are setting this Schema in our Models as 'Post'
var Post = mongoose.model('Post') // We are retrieving this Schema from our Models, named 'Post'
var Comment = mongoose.model('Comment')


//!! GETS

app.get('/', function (req, res) {
  Post.find({},
    function (err, posts) {
      console.log(posts);
      res.render('index', {
        posts: posts,
        moment: moment
      })
    })
})

// app.get('/', function (req, res) {
//     Post.find({},
//         function (err, posts) {
//             console.log(posts);
//             Comment.find({},
//                 function (err, comments) {
//                     console.log(comments);
//                     res.render('index', {
//                         posts: posts,
//                         moment: moment,
//                         comments: comments
//                     })
//                 })
//         })
// })


// app.get('/quotes', function (req, res) {
//     Quote.find({}, null, {
//         sort: {
//             created_at: -1
//         }
//     }, function (err, quotes) {
//         console.log("Data:");


//         console.log(quotes);
//         res.render('quotes', {
//             quotes: quotes,
//             moment: moment
//         });
//     })
// })


//!! POSTS


app.post('/postMessage', function (req, res) {
  console.log(req.body);

  var post = new Post({
    name: req.body.name,
    post: req.body.post,
  });

  post.save(function (err) {
    if (err) {
      for (var key in err.errors) {
        req.flash('registration', err.errors[key].message);
      }
      console.log("Error!", err);
      res.redirect('/');
    } else {
      console.log('Successfully added a post!');
      res.redirect('/');
    }
  })
})

//? Works but does not validate because of hard coding
app.post('/postComment/:id', (req, res) => {
  Post.findOneAndUpdate(
    { _id: req.params.id },
    { $push: { Comment: req.body } },
    { runValidators: true })
    .then(() => res.redirect('/'))
    .catch(err => {
      for (var key in err.errors) {
        req.flash('registration', err.errors[key].message);
      }
      console.log('Error!')
      res.redirect('/');
    });
});





// app.post('/submit', function (req, res) {
//     console.log("POST DATA", req.body);

//     var quote = new Quote({
//         name: req.body.name,
//         quote: req.body.quote,
//         created_at: Date.now()
//     });
//     quote.save(function (err) {
//         if (err) {
//             console.log("We have an error!", err);
//             for (var key in err.errors) {
//                 req.flash('registration', err.errors[key].message);
//             }
//             res.redirect('/');
//         } else {
//             console.log('Successfully added a quote!');
//             var formatted_date = moment(req.body.created_at).format('HH:mm a MMMM Do YYYY');
//             res.render('result', {
//                 quote: req.body,
//                 date: formatted_date
//             });
//         }
//     })
// })

//! DELETE ONE OBJECT
// app.post('/delete', function (req, res) {
//     console.log("Deleting User Object with id:", req.body._id);
//     User.remove({
//         _id: req.body._id
//     }, function (err) {
//         res.redirect('/');
//     })
// })

//! DELETE ALL OBJECTS
// app.post('/deleteAll', function (req, res) {
//     User.remove({}, function (err) {
//         console.log("Deleted All Data");
//         res.redirect('/');
//     })
// })



//! Setting our Server to Listen on Port: 8000
app.listen(8000, function () {
  console.log("listening on port 8000");
})